<script setup lang="ts">
defineProps<{
    currentDate: Date;
}>();

const emit = defineEmits<{
    (event: "previous"): void;
    (event: "next"): void;
    (event: "today"): void;
}>();

function getWeekLabel(date: Date) {
    const start = new Date(date);
    const day = start.getDay();
    start.setDate(start.getDate() - day);

    const end = new Date(start);
    end.setDate(start.getDate() + 6);

    const options: Intl.DateTimeFormatOptions = {
        month: "short",
        day: "numeric",
    };

    return `${start.toLocaleDateString(undefined, options)} – ${end.toLocaleDateString(
        undefined,
        {
            ...options,
            year: "numeric",
        },
    )}`;
}
</script>

<template>
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <p class="mt-1 text-sm text-gray-500">
                {{ getWeekLabel(currentDate) }}
            </p>
        </div>

        <div class="flex items-center gap-2">
            <button
                type="button"
                class="rounded-lg border border-gray-200 px-3 py-2 text-sm text-gray-600 hover:bg-gray-50"
                @click="emit('today')"
            >
                Today
            </button>

            <div class="flex overflow-hidden rounded-lg border border-gray-200">
                <button
                    type="button"
                    aria-label="Previous week"
                    class="px-3 py-2 text-gray-600 hover:bg-gray-50"
                    @click="emit('previous')"
                >
                    ←
                </button>
                <div class="w-px bg-gray-200" />
                <button
                    type="button"
                    aria-label="Next week"
                    class="px-3 py-2 text-gray-600 hover:bg-gray-50"
                    @click="emit('next')"
                >
                    →
                </button>
            </div>
        </div>
    </div>
</template>
