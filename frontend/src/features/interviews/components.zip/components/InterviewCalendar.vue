<script setup lang="ts">
import { computed } from "vue";
import type { Interview } from "../types/interview.types";
import InterviewCard from "./InterviewCard.vue";

const props = defineProps<{
    interviews: Interview[];
    currentDate: Date;
}>();

const emit = defineEmits<{
    (event: "select", interview: Interview): void;
}>();

const weekDays = computed(() => {
    const start = new Date(props.currentDate);
    start.setHours(0, 0, 0, 0);
    start.setDate(start.getDate() - start.getDay());

    return Array.from({ length: 7 }, (_, index) => {
        const date = new Date(start);
        date.setDate(start.getDate() + index);
        return date;
    });
});

const hours = Array.from({ length: 11 }, (_, index) => index + 8);

function interviewsForDay(date: Date) {
    return props.interviews.filter((interview) => {
        const scheduled = new Date(interview.scheduled_at);

        return (
            scheduled.getFullYear() === date.getFullYear() &&
            scheduled.getMonth() === date.getMonth() &&
            scheduled.getDate() === date.getDate()
        );
    });
}

function interviewsForHour(date: Date, hour: number) {
    return interviewsForDay(date).filter(
        (interview) => new Date(interview.scheduled_at).getHours() === hour,
    );
}
</script>

<template>
    <div class="overflow-x-auto rounded-xl border border-gray-200 bg-white">
        <div class="min-w-225">
            <div
                class="grid grid-cols-[65px_repeat(7,minmax(110px,1fr))] border-b border-gray-200 bg-gray-50"
            >
                <div class="border-r border-gray-200 p-3" />

                <div
                    v-for="day in weekDays"
                    :key="day.toISOString()"
                    class="border-r border-gray-200 p-3 text-center last:border-r-0"
                >
                    <p class="text-xs font-medium text-gray-500">
                        {{
                            day.toLocaleDateString(undefined, {
                                weekday: "short",
                            })
                        }}
                    </p>
                    <p class="mt-1 text-sm font-semibold text-gray-900">
                        {{ day.getDate() }}
                    </p>
                </div>
            </div>

            <div
                v-for="hour in hours"
                :key="hour"
                class="grid grid-cols-[65px_repeat(7,minmax(110px,1fr))]"
            >
                <div
                    class="border-b border-r border-gray-200 px-2 py-3 text-right text-xs text-gray-400"
                >
                    {{
                        new Date(2000, 0, 1, hour).toLocaleTimeString([], {
                            hour: "numeric",
                        })
                    }}
                </div>

                <div
                    v-for="day in weekDays"
                    :key="`${day.toISOString()}-${hour}`"
                    class="min-h-28 space-y-2 border-b border-r border-gray-100 p-2 last:border-r-0"
                >
                    <InterviewCard
                        v-for="interview in interviewsForHour(day, hour)"
                        :key="interview.id"
                        :interview="interview"
                        @select="emit('select', $event)"
                    />
                </div>
            </div>
        </div>
    </div>
</template>
