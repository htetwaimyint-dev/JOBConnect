<script setup lang="ts">
import type { Interview } from "../types/interview.types";

defineProps<{
    interview: Interview;
}>();

defineEmits<{
    (event: "select", interview: Interview): void;
}>();

function timeLabel(value: string) {
    return new Date(value).toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit",
    });
}
</script>

<template>
    <button
        type="button"
        class="w-full rounded-lg border border-indigo-100 bg-indigo-50/80 p-3 text-left transition hover:border-indigo-300 hover:bg-indigo-50"
        @click="$emit('select', interview)"
    >
        <div class="flex items-start justify-between gap-2">
            <span class="text-xs font-semibold text-indigo-700">
                {{ timeLabel(interview.scheduled_at) }}
            </span>
            <span
                class="rounded-full px-2 py-0.5 text-[10px] font-medium capitalize"
                :class="{
                    'bg-green-100 text-green-700':
                        interview.status === 'completed',
                    'bg-red-100 text-red-700': interview.status === 'cancelled',
                    'bg-indigo-100 text-indigo-700':
                        interview.status === 'scheduled',
                    'bg-amber-100 text-amber-700':
                        interview.status === 'rescheduled',
                }"
            >
                {{ interview.status }}
            </span>
        </div>

        <p class="mt-2 text-sm font-semibold text-gray-900">
            {{ interview.application?.applicant_name ?? "Applicant" }}
        </p>

        <p class="mt-1 line-clamp-1 text-xs text-gray-600">
            {{ interview.application?.job?.title ?? "Job title unavailable" }}
        </p>

        <div class="mt-3 flex flex-wrap gap-1">
            <span
                v-for="person in interview.interviewers"
                :key="person.id"
                class="rounded-full bg-white px-2 py-1 text-[10px] text-gray-600"
            >
                {{ person.name }}
            </span>
        </div>
    </button>
</template>
