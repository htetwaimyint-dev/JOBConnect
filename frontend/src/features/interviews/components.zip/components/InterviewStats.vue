<script setup lang="ts">
import { computed } from "vue";
import type { Interview } from "../types/interview.types";

const props = defineProps<{
    interviews: Interview[];
}>();

const stats = computed(() => {
    const today = new Date().toDateString();

    return [
        {
            label: "Total Interviews",
            value: props.interviews.length,
            icon: "📅",
            description: "All scheduled interviews",
        },
        {
            label: "Today",
            value: props.interviews.filter(
                (item) =>
                    new Date(item.scheduled_at).toDateString() === today &&
                    item.status === "scheduled",
            ).length,
            icon: "☀️",
            description: "Scheduled for today",
        },
        {
            label: "Completed",
            value: props.interviews.filter(
                (item) => item.status === "completed",
            ).length,
            icon: "✓",
            description: "Finished interviews",
        },
        {
            label: "Cancelled",
            value: props.interviews.filter(
                (item) => item.status === "cancelled",
            ).length,
            icon: "↗",
            description: "Cancelled interviews",
        },
    ];
});
</script>

<template>
    <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <div
            v-for="stat in stats"
            :key="stat.label"
            class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
        >
            <div class="flex items-center justify-between">
                <p class="text-sm font-medium text-gray-500">
                    {{ stat.label }}
                </p>
                <span
                    class="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-50 text-lg text-indigo-600"
                >
                    {{ stat.icon }}
                </span>
            </div>

            <p class="mt-3 text-2xl font-bold text-gray-900">
                {{ stat.value }}
            </p>

            <p class="mt-1 text-xs text-gray-500">
                {{ stat.description }}
            </p>
        </div>
    </div>
</template>
